﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace NWCTXT2Ly
{
	// Use the staff properties to decide whether it's a chord staff or whatever - page 123 of notation reference
	// Options: remove empty staves
	//	font size
	//	Multivoice rest position
	
	// Fix bug over multiple runs - done
	
	public partial class MainForm : Form
	{
		StreamReader NWCTextFile;
		StreamWriter LilyPondFile;
		StreamWriter NWCStaffFile;
		List<StaffInfo> StaffNames = new List<StaffInfo>();
		List<string> InputLines = new List<string>();
		string CurrentDir;
		bool RemoveEmptyStaves;
		bool RemoveFirst;
		bool UseVoice;
		int FontSize;
		string ScoreName="";
		bool UseAcc=true;
		bool ForcePage;
		bool SmallFonts;
		string FileNameArg;

		public MainForm(string FileName)
		{
			FileNameArg = FileName;
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			if (Application.UserAppDataRegistry.GetValue("Filename") != null)
			{
				txtFile.Text = Application.UserAppDataRegistry.GetValue("Filename").ToString();
				btnGo.Enabled = true;
			}
			if (Application.UserAppDataRegistry.GetValue("RemoveEmptyStaves") != null)
			{
				chkRemove.Checked = bool.Parse(Application.UserAppDataRegistry.GetValue("RemoveEmptyStaves").ToString());
				if (chkRemove.Checked) chkFirstStave.Enabled = true;
			}
			if (Application.UserAppDataRegistry.GetValue("RemoveFirst") != null)
			{
				chkFirstStave.Checked = bool.Parse(Application.UserAppDataRegistry.GetValue("RemoveFirst").ToString());
			}
			if (Application.UserAppDataRegistry.GetValue("FontSize") != null)
			{
				FontSize = int.Parse(Application.UserAppDataRegistry.GetValue("FontSize").ToString());
				udFontSize.Value = FontSize;
			}
			else
			{
				FontSize = (int)udFontSize.Value;
				Application.UserAppDataRegistry.SetValue("FontSize", FontSize.ToString());
			}
			if (Application.UserAppDataRegistry.GetValue("UseVoice") != null)
			{
				chkVoice.Checked = bool.Parse(Application.UserAppDataRegistry.GetValue("UseVoice").ToString());
			}
			if (Application.UserAppDataRegistry.GetValue("ScoreName") != null)
			{
				txtName.Text = Application.UserAppDataRegistry.GetValue("ScoreName").ToString();
			}
			if (Application.UserAppDataRegistry.GetValue("UseAcc") != null)
			{
				radAcc.Checked = bool.Parse(Application.UserAppDataRegistry.GetValue("UseAcc").ToString());
				radGrace.Checked = !radAcc.Checked;
			}
			if (Application.UserAppDataRegistry.GetValue("ForcePage") != null)
			{
				chkForcePage.Checked = bool.Parse(Application.UserAppDataRegistry.GetValue("ForcePage").ToString());
			}
			if (Application.UserAppDataRegistry.GetValue("SmallFonts") != null)
			{
				chkSmall.Checked = bool.Parse(Application.UserAppDataRegistry.GetValue("SmallFonts").ToString());
			}
			if (FileNameArg != "")
			{
				txtFile.Text = FileNameArg;
				ProcessFile();
				Application.Exit();
			}
		}

		private void btnBrowse_Click(object sender, EventArgs e)
		{
			OpenFileDialog ofnSource = new OpenFileDialog();
			ofnSource.Filter = "Noteworthy Text files (*.nwctxt)|*.nwctxt";
			if (ofnSource.ShowDialog() == DialogResult.OK)
			{
				txtFile.Text = ofnSource.FileName;
				Application.UserAppDataRegistry.SetValue("Filename", txtFile.Text);
				btnGo.Enabled = true;
			}

		}

		private void btnGo_Click(object sender, EventArgs e)
		{
			ProcessFile();
		}
		private void ProcessFile()
		{
			if (FontSize < 2)
			{
				MessageBox.Show("Warning: Font Size is set to " + FontSize.ToString() + ".  Please set it to a larger figure and try again");
				return;
			}
			btnGo.Enabled = false;
			Cursor OldCursor = this.Cursor;
			this.Cursor = Cursors.WaitCursor;

			try
			{
				Encoding isoIn = Encoding.GetEncoding(28591);
				NWCTextFile = new StreamReader(txtFile.Text.ToString(), isoIn);
			}
			/*			try
						{
							NWCTextFile = new StreamReader(txtFile.Text.ToString());
						}*/
			catch (Exception)
			{
				MessageBox.Show("Unable to read file " + txtFile.Text.ToString(), "NWC2LY");
				return;
			}
			FileInfo Info = new FileInfo(txtFile.Text.ToString());
			string Line, CopyLine;
			string Command;
			string StaffName = "";
			string Headers = "";
			CurrentDir = Info.DirectoryName + "\\";
			char LyricName = 'A';

			StaffNames.Clear();

			string LilyPondFileName = txtFile.Text.ToString();
			LilyPondFileName = LilyPondFileName.Replace(Info.Extension, ".ly");

			while (NWCTextFile.Peek() >= 0)
			{
				Line = NWCTextFile.ReadLine();
				InputLines.Add(Line);
			}
			while (InputLines.Count > 0)
			{
				Line = CopyLine = InputLines[0];
				InputLines.RemoveAt(0);
				Command = nwc2ly.nwc2ly.GetCommand(ref Line);
				switch (Command)
				{
					case "SongInfo":
						{
							Headers = DoHeaders(Line, "123");
							break;
						}
					case "PgSetup":
						{
							break;
						}
					case "Font":
						{
							break;
						}
					case "PgMargins":
						{
							break;
						}
					case "AddStaff":
						{
							StaffName = nwc2ly.nwc2ly.GetPar("Name", Line);
							if (StaffName == "")
							{
								// Do something here to create a name
							}
							StaffInfo Staff = new StaffInfo();
							Staff.Label = StaffName; // This is used for creating solo parts
							StaffName = StaffName.Replace("\"", "");
							StaffName = StaffName.Replace(" ", "");
							StaffName = StaffName.Replace("/", "");
							StaffName = StaffName.Replace("\\", "");
							Staff.FileName = txtName.Text + StaffName;
							StaffNames.Add(Staff);
							break;
						}
					case "StaffProperties":
						{
							string Layer = nwc2ly.nwc2ly.GetPar("Layer", Line);
							if (Layer != "")
							{
								StaffNames[StaffNames.Count - 1].Layer = Layer;
							}
							string StaffLabel = StaffNames[StaffNames.Count - 1].Label.ToLower();

							if (StaffLabel.IndexOf("solo") > 0)
							{
								StaffNames[StaffNames.Count - 1].Type = "Solo";
							}
							else
							{
								string Style = nwc2ly.nwc2ly.GetPar("Style", Line);
								if (Style != "")
								{
									StaffNames[StaffNames.Count - 1].Type = Style;
								}
							}
							break;
						}
					case "StaffInstrument":
						{
							break;
						}
					case "Lyrics":
						{
							if (Line.IndexOf("Placement:Top") >= 0)
							{
								StaffNames[StaffNames.Count - 1].bLyricsTop = true;
							}
							GetLyrics(ref LyricName);
							break;
						}
					case "Clef":
						{
							NWCStaffFile = new StreamWriter(CurrentDir + txtName.Text + StaffName + ".nwcextract");
							GetNoteInfo(CopyLine);
							NWCStaffFile.Close();
							string DynamicDir = "Down";
							if (StaffNames[StaffNames.Count - 1].Type == "Standard" || StaffNames[StaffNames.Count - 1].Type == "Solo")
							{
								DynamicDir = "Up";
							}
							string[] args = { CurrentDir + txtName.Text + StaffName + ".nwcextract", CurrentDir + txtName.Text + StaffName + ".ly", DynamicDir, UseAcc.ToString() };
							nwc2ly.nwc2ly.Main(args);
							break;
						}
				}
			}
			LilyPondFile = new StreamWriter(LilyPondFileName, false);
			string ver = Application.ProductVersion;
			LilyPondFile.WriteLine("% Generated by NWCTXT2Ly C# version " + ver + " by Phil Holmes");
			LilyPondFile.WriteLine("% Based on nwc2ly by Mike Wiering");
			LilyPondFile.WriteLine("");
			LilyPondFile.WriteLine("\\version \"2.8.0\"");
			LilyPondFile.WriteLine("\\pointAndClickOff");
			LilyPondFile.WriteLine("#(set-global-staff-size " + FontSize.ToString() + ")");
			LilyPondFile.WriteLine("");

			LilyPondFile.WriteLine(Headers);

			if (chkRemove.Checked)
			{
				LilyPondFile.WriteLine("\\layout {");
				LilyPondFile.WriteLine("  \\context {");
				LilyPondFile.WriteLine("    \\RemoveEmptyStaffContext");
				if (chkFirstStave.Checked)
				{
					LilyPondFile.WriteLine("    \\override VerticalAxisGroup #'remove-first = ##t");
				}
				LilyPondFile.WriteLine("  }");
				LilyPondFile.WriteLine("}");
			}

			LilyPondFile.WriteLine("\\new Score \\with {");
			if (chkForcePage.Checked)
			{
				LilyPondFile.WriteLine("\\override NonMusicalPaperColumn #'page-break-permission = ##f");
			}
			LilyPondFile.WriteLine("\\override PaperColumn #'keep-inside-line = ##t");
			LilyPondFile.WriteLine("\\override NonMusicalPaperColumn #'keep-inside-line = ##t");

			LilyPondFile.WriteLine("}");
			LilyPondFile.WriteLine("{");


			LilyPondFile.WriteLine("<<");

			WriteVoices();

			LilyPondFile.WriteLine(">>");

			LilyPondFile.WriteLine("}");
			LilyPondFile.Close();
			NWCTextFile.Close();
			this.Cursor = OldCursor;
			btnGo.Enabled = true;
		}
		private void WriteLyricDetails(StaffInfo StaffName, ref char LyricName, int StaveNumber)
		{
			string FontSize = "";
			if (StaffName.Type == "Solo")
			{
				if (chkSmall.Checked == true)
				{
					FontSize = " \\tiny ";
				}
			}
			if (StaffName.LyricLines > 0)
			{
				for (int i = 0; i < StaffName.LyricLines; i++)
				{
					if (StaffName.bLyricsTop)
					{
						LilyPondFile.WriteLine("\\new Lyrics \\with { alignAboveContext = " + (char)(StaveNumber + 'A') + "Stave } \\lyricsto \"" + StaffName.FileName + "\" { " + FontSize + " << \\include \"" + StaffName.FileName + LyricName + "lyrics.ly" + "\" >> }");
					}
					else
					{
						LilyPondFile.WriteLine("\\new Lyrics \\lyricsto \"" + StaffName.FileName + "\" { " + FontSize + " << \\include \"" + StaffName.FileName + LyricName + "lyrics.ly" + "\" >> }");
					}
					LyricName++;
				}
			}
		}
		private void WriteVoices()
		{
			string Layer;
			bool Layering = false;
			char Name1 = 'A', Name2 = 'A';
			char LyricName = 'A';
			string[] VoiceNames = { "\\voiceOne", "\\voiceTwo", "\\voiceThree", "\\voiceFour" };
			int VoiceNumber = 0;
			int Staves = 0;
			string StaveType = "";
			string NewStaveType;
			string ThisVoiceName;
			string FontSize = "";

			for (int i = 0; i < StaffNames.Count; i++)
			{
				FontSize = "";
				NewStaveType = StaffNames[i].Type;
				if (StaveType != NewStaveType)
				{
					if (StaveType != "Upper Grand Staff" && NewStaveType != "Lower Grand Staff")
					{
						if (i > 0)
						{
							LilyPondFile.WriteLine(">>");
						}
						switch (NewStaveType)
						{
							case "Solo":
								{
									LilyPondFile.WriteLine("<<");
									if (chkSmall.Checked == true)
									{
										FontSize = " \\tiny ";
									}
									break;
								}
							case "Standard":
								{
									LilyPondFile.WriteLine("\\new ChoirStaff <<");
									LilyPondFile.WriteLine("\\override ChoirStaff.SystemStartBracket #'collapse-height = #1");
									LilyPondFile.WriteLine("\\override Score.SystemStartBar #'collapse-height = #1");
									break;
								}
							case "Orchestral":
								{
									LilyPondFile.WriteLine("\\new StaffGroup <<");
									break;
								}
							case "Upper Grand Staff":
							case "Lower Grand Staff":
								{
									LilyPondFile.WriteLine("\\new PianoStaff <<");
									break;
								}
							default:
								{
									break;
								}

						}
					}
					StaveType = NewStaveType;
				}
				ThisVoiceName = "";
				Layer = StaffNames[i].Layer;
				if (Layer == "N" && Layering)  // New voice on existing stave - layering = false - need to end stave
				{
					VoiceNumber++;
					if (UseVoice)
					{
						ThisVoiceName = VoiceNames[VoiceNumber];
					}
					LilyPondFile.WriteLine("\\new Voice = \"" + StaffNames[i].FileName + "\" { " + FontSize + ThisVoiceName + " << \\include \"" + StaffNames[i].FileName + ".ly\" >> }");
					WriteLyricDetails(StaffNames[i], ref LyricName, Staves);
					LilyPondFile.WriteLine(">>");
					Layering = false;
					Staves++;
				}
				else if (Layer == "Y" && Layering) // New voice on existing stave - layering = true
				{
					VoiceNumber++;
					if (UseVoice)
					{
						ThisVoiceName = VoiceNames[VoiceNumber];
					}
					LilyPondFile.WriteLine("\\new Voice = \"" + StaffNames[i].FileName + "\" { " + FontSize + ThisVoiceName + " << \\include \"" + StaffNames[i].FileName + ".ly\" >> }");
					WriteLyricDetails(StaffNames[i], ref LyricName, Staves);
				}
				else if (Layer == "N" && !Layering) // Only voice on new stave - layering = false
				{
					VoiceNumber = 0;
					LilyPondFile.WriteLine("\\new Staff = " + (char)(Staves+'A') + "Stave <<");
					LilyPondFile.WriteLine("\\new Voice = \"" + StaffNames[i].FileName + "\" { " + FontSize + " << \\include \"" + StaffNames[i].FileName + ".ly\" >> }");
					WriteLyricDetails(StaffNames[i], ref LyricName, Staves);
					LilyPondFile.WriteLine(">>");
					Layering = false;
					Staves++;
				}
				else if (Layer == "Y" && !Layering)  // First voice on new stave - layering = true
				{
					VoiceNumber = 0;
					if (UseVoice)
					{
						ThisVoiceName = VoiceNames[VoiceNumber];
					}
					LilyPondFile.WriteLine("\\new Staff = " + (char)(Staves + 'A') + "Stave <<");
					LilyPondFile.WriteLine("\\new Voice = \"" + StaffNames[i].FileName + "\" { " + FontSize + ThisVoiceName + " << \\include \"" + StaffNames[i].FileName + ".ly\" >> }");
					WriteLyricDetails(StaffNames[i], ref LyricName, Staves);
					Layering = true;
				}
				else
				{  // Bizarre - can't happen
				}
				Name1++;
				if (Name1 == 'Z')
				{
					Name2++;
					Name1 = 'A';
				}
			}
			LilyPondFile.WriteLine(">>");
			txtResult.Text = Staves.ToString() + " staves written with " + StaffNames.Count.ToString() + " voices.";
		}
		private void GetNoteInfo(string FirstLine)
		{
			string Input, InputCopy;
			string Command;

			NWCStaffFile.WriteLine("!NoteWorthyComposerClip(2.0,Single)");
			NWCStaffFile.WriteLine(FirstLine);
	
			Input = InputCopy = InputLines[0];
			InputLines.RemoveAt(0);
			Command = nwc2ly.nwc2ly.GetCommand(ref InputCopy);
			while (Command != "AddStaff" && InputLines.Count > 0)
			{
				NWCStaffFile.WriteLine(Input);

				Input = InputCopy = InputLines[0];
				InputLines.RemoveAt(0);
				Command = nwc2ly.nwc2ly.GetCommand(ref InputCopy);
			}
			InputLines.Insert(0, Input);
			NWCStaffFile.Close();
		}
		private void GetLyrics(ref char Name)
		{
			string Input;
			string Command;
			Regex FindParen = new Regex(@"\(\w+");
			Regex FindNumbers = new Regex(@"(([0-9])[^\s]+)");
			// Regex FindUnderscore = new Regex("[\"\\s]_[\"\\s]");
			Regex FindUnderscore = new Regex("_\\s");
			Regex FindUnicode = new Regex(@"(\w*)([\u0090-\u00ff])(\w*)");

			int LyricCount = 0;

			Input = InputLines[0];
			while (Input.Substring(0, 6) == "|Lyric")
			{
				StreamWriter LyricFile = new StreamWriter(CurrentDir + StaffNames[StaffNames.Count - 1].FileName + Name + "lyrics.ly");
				LyricFile.WriteLine("{ ");
				Command = nwc2ly.nwc2ly.GetCommand(ref Input);
				if (Command.Substring(0, 5) != "Lyric")
				{
					// Shouldn't happen
				}

				Input = FindParen.Replace(Input, "\"$&\"");  // Replaces (text with "(text"
				Input = FindNumbers.Replace(Input, "\"$&\"");  // Puts numerals in inverted commas
				Input = FindUnderscore.Replace(Input, "\" \"");  // Replace underscore with space in inverted comma
				Input = Input.Replace("|Text:\"", "");
				Input = Input.Replace("-", " -- ");
				Input = Input.Replace("\\'", "'");
				Input = Input.Replace("\\\"", "''");
				Input = Input.Replace("\\r", "\r");
				Input = Input.Replace("\\n", "\n");
				Input = Input.Replace("_", " ");
				Input = Input.Replace("<i>", " \\override LyricText #'font-shape = #'italic ");
				Input = Input.Replace(@"<\\i>", " \\override LyricText #'font-shape = #'normal ");

				MatchCollection UnicodeMatches = FindUnicode.Matches(Input);

				foreach (Match UnicodeMatch in UnicodeMatches)
				{
					char UnicodeChar;
					string UnicodeString = UnicodeMatch.ToString();
					int UnicodeVal;
					string ReplacementString = @"\markup{ \concat{ ";
					for (int j = 0; j < UnicodeString.Length; j++)
					{
						UnicodeChar = UnicodeString[j];
						UnicodeVal = (int)UnicodeChar;
						if (UnicodeVal < 128)
						{
							ReplacementString += UnicodeChar.ToString();
						}
						else
						{
							ReplacementString += @"\char ##x00";
							ReplacementString += UnicodeVal.ToString("X2") + " ";
						}
					}
					ReplacementString += "} }";
					int iPos = Input.IndexOf(UnicodeString);
					Input = Input.Remove(iPos, UnicodeString.Length);
					Input = Input.Insert(iPos, ReplacementString);
					//Input = Input.Replace(UnicodeString, ReplacementString);
				}

				Input = Input.Substring(0, Input.Length - 1);
				LyricFile.Write(Input);  // We might add a tab at the start at some point
				InputLines.RemoveAt(0);
				Input = InputLines[0];
				LyricFile.WriteLine(" }");
				LyricFile.Close();
				Name++;
				LyricCount++;
			}
			StaffNames[StaffNames.Count - 1].LyricLines = LyricCount;
		}
		private string DoHeaders(string SongInfo, string SongNumber)
		{
			StringBuilder Header = new StringBuilder();
			string[] ParameterList;
			string[,] HeaderKey = {{"Title:", "subtitle = \\markup {\\fontsize #5 \"", "\"}" },
								  {"Author:", "composer = \"Music: ", "\""},
								  {"Lyricist:", "poet = \"Lyrics: ", "\""},
								  {"Copyright1:", "copyright = \"", "\""},
								  {"Comments:", @"title = \markup \fill-line { \line {} \line { ", "} }"}};


			Header.AppendLine("\\header {");

			ParameterList = SongInfo.Split('|');

			string Param;
			for (int i = 0; i < ParameterList.Length; i++)
			{
				Param = ParameterList[i];
				for (int j = 0; j < HeaderKey.GetLength(0); j++)
				{
					if (Param.Length > 0)
					{
						if (Param.IndexOf(HeaderKey[j, 0]) >= 0)
						{
							Param = Param.Replace(HeaderKey[j, 0], "");
							Param = Param.Replace("\"", "");
							Param = Param.Replace("\\", "");
							if (Param.Length > 0)
							{
								Header.AppendLine(HeaderKey[j, 1] + Param + HeaderKey[j, 2]);
							}
						}
					}
				}
			}

			Header.AppendLine("}");
			Header.AppendLine("");
			return Header.ToString();
		}

		private void chkRemove_CheckedChanged(object sender, EventArgs e)
		{
			RemoveEmptyStaves = chkRemove.Checked;
			Application.UserAppDataRegistry.SetValue("RemoveEmptyStaves", RemoveEmptyStaves.ToString());
			if (chkRemove.Checked)
			{
				chkFirstStave.Enabled = true;
			}
		}

		private void udFontSize_ValueChanged(object sender, EventArgs e)
		{
			FontSize = (int)udFontSize.Value;
			Application.UserAppDataRegistry.SetValue("FontSize", FontSize.ToString());
		}

		private void chkFirstStave_CheckedChanged(object sender, EventArgs e)
		{
			RemoveFirst = chkFirstStave.Checked;
			Application.UserAppDataRegistry.SetValue("RemoveFirst", RemoveFirst.ToString());
		}

		private void chkVoice_CheckedChanged(object sender, EventArgs e)
		{
			UseVoice = chkVoice.Checked;
			Application.UserAppDataRegistry.SetValue("UseVoice", UseVoice.ToString());
		}

		private void txtName_TextChanged(object sender, EventArgs e)
		{
			bool Valid = true;
			for (int i = 0; i < txtName.Text.Length; i++)
			{
				if (!char.IsLetter(txtName.Text[i]))
				{
					Valid = false;
					break;
				}
			}
			if (!Valid)
			{
				MessageBox.Show("Name can only contain letters", "NWCTXT2Ly");
				txtName.Text = txtName.Text.Substring(0, txtName.Text.Length - 1);
			}
			ScoreName = txtName.Text;
			Application.UserAppDataRegistry.SetValue("ScoreName", ScoreName);
		}

		private void radAcc_CheckedChanged(object sender, EventArgs e)
		{
			UseAcc = false;
			if (radAcc.Checked)
			{
				UseAcc = true;
			}
			Application.UserAppDataRegistry.SetValue("UseAcc", UseAcc.ToString());
		}

		private void chkForcePage_CheckedChanged(object sender, EventArgs e)
		{
			ForcePage = chkForcePage.Checked;
			Application.UserAppDataRegistry.SetValue("ForcePage", ForcePage.ToString());
		}

		private void chkSmall_CheckedChanged(object sender, EventArgs e)
		{
			SmallFonts = chkSmall.Checked;
			Application.UserAppDataRegistry.SetValue("SmallFonts", SmallFonts.ToString());
		}
	}
	public class StaffInfo
	{
		public string FileName;
		public int Voice;
		public string Layer;
		public int LyricLines = 0;
		public string Type;
		public string Label="";
		public bool bLyricsTop = false;
	}
}
