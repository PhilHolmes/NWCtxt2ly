﻿namespace NWCTXT2Ly
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.btnBrowse = new System.Windows.Forms.Button();
			this.txtFile = new System.Windows.Forms.TextBox();
			this.lblFile = new System.Windows.Forms.Label();
			this.btnGo = new System.Windows.Forms.Button();
			this.txtResult = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.chkRemove = new System.Windows.Forms.CheckBox();
			this.udFontSize = new System.Windows.Forms.NumericUpDown();
			this.label2 = new System.Windows.Forms.Label();
			this.chkFirstStave = new System.Windows.Forms.CheckBox();
			this.chkVoice = new System.Windows.Forms.CheckBox();
			this.txtName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.grpGrace = new System.Windows.Forms.GroupBox();
			this.radGrace = new System.Windows.Forms.RadioButton();
			this.radAcc = new System.Windows.Forms.RadioButton();
			this.chkForcePage = new System.Windows.Forms.CheckBox();
			this.chkSmall = new System.Windows.Forms.CheckBox();
			((System.ComponentModel.ISupportInitialize)(this.udFontSize)).BeginInit();
			this.grpGrace.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnBrowse
			// 
			this.btnBrowse.Location = new System.Drawing.Point(418, 8);
			this.btnBrowse.Name = "btnBrowse";
			this.btnBrowse.Size = new System.Drawing.Size(75, 23);
			this.btnBrowse.TabIndex = 5;
			this.btnBrowse.Text = "Browse...";
			this.btnBrowse.UseVisualStyleBackColor = true;
			this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
			// 
			// txtFile
			// 
			this.txtFile.Location = new System.Drawing.Point(81, 11);
			this.txtFile.Name = "txtFile";
			this.txtFile.Size = new System.Drawing.Size(331, 20);
			this.txtFile.TabIndex = 4;
			// 
			// lblFile
			// 
			this.lblFile.AutoSize = true;
			this.lblFile.Location = new System.Drawing.Point(28, 14);
			this.lblFile.Name = "lblFile";
			this.lblFile.Size = new System.Drawing.Size(47, 13);
			this.lblFile.TabIndex = 3;
			this.lblFile.Text = "Input file";
			// 
			// btnGo
			// 
			this.btnGo.Enabled = false;
			this.btnGo.Location = new System.Drawing.Point(418, 37);
			this.btnGo.Name = "btnGo";
			this.btnGo.Size = new System.Drawing.Size(75, 23);
			this.btnGo.TabIndex = 6;
			this.btnGo.Text = "Go";
			this.btnGo.UseVisualStyleBackColor = true;
			this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
			// 
			// txtResult
			// 
			this.txtResult.Location = new System.Drawing.Point(81, 40);
			this.txtResult.Name = "txtResult";
			this.txtResult.ReadOnly = true;
			this.txtResult.Size = new System.Drawing.Size(331, 20);
			this.txtResult.TabIndex = 7;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(29, 87);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(46, 13);
			this.label1.TabIndex = 8;
			this.label1.Text = "Options:";
			// 
			// chkRemove
			// 
			this.chkRemove.AutoSize = true;
			this.chkRemove.Location = new System.Drawing.Point(81, 86);
			this.chkRemove.Name = "chkRemove";
			this.chkRemove.Size = new System.Drawing.Size(131, 17);
			this.chkRemove.TabIndex = 9;
			this.chkRemove.Text = "Remove empty staves";
			this.chkRemove.UseVisualStyleBackColor = true;
			this.chkRemove.CheckedChanged += new System.EventHandler(this.chkRemove_CheckedChanged);
			// 
			// udFontSize
			// 
			this.udFontSize.Location = new System.Drawing.Point(81, 109);
			this.udFontSize.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
			this.udFontSize.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
			this.udFontSize.Name = "udFontSize";
			this.udFontSize.Size = new System.Drawing.Size(35, 20);
			this.udFontSize.TabIndex = 10;
			this.udFontSize.Value = new decimal(new int[] {
            18,
            0,
            0,
            0});
			this.udFontSize.ValueChanged += new System.EventHandler(this.udFontSize_ValueChanged);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(122, 111);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(51, 13);
			this.label2.TabIndex = 11;
			this.label2.Text = "Font Size";
			// 
			// chkFirstStave
			// 
			this.chkFirstStave.AutoSize = true;
			this.chkFirstStave.Enabled = false;
			this.chkFirstStave.Location = new System.Drawing.Point(218, 87);
			this.chkFirstStave.Name = "chkFirstStave";
			this.chkFirstStave.Size = new System.Drawing.Size(163, 17);
			this.chkFirstStave.TabIndex = 12;
			this.chkFirstStave.Text = "Also remove empty first stave";
			this.chkFirstStave.UseVisualStyleBackColor = true;
			this.chkFirstStave.CheckedChanged += new System.EventHandler(this.chkFirstStave_CheckedChanged);
			// 
			// chkVoice
			// 
			this.chkVoice.AutoSize = true;
			this.chkVoice.Location = new System.Drawing.Point(81, 135);
			this.chkVoice.Name = "chkVoice";
			this.chkVoice.Size = new System.Drawing.Size(335, 17);
			this.chkVoice.TabIndex = 13;
			this.chkVoice.Text = "Assign voice names (voiceOne, voiceTwo, etc.) to layered staves";
			this.chkVoice.UseVisualStyleBackColor = true;
			this.chkVoice.CheckedChanged += new System.EventHandler(this.chkVoice_CheckedChanged);
			// 
			// txtName
			// 
			this.txtName.Location = new System.Drawing.Point(81, 158);
			this.txtName.Name = "txtName";
			this.txtName.Size = new System.Drawing.Size(100, 20);
			this.txtName.TabIndex = 14;
			this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(17, 161);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(58, 13);
			this.label3.TabIndex = 15;
			this.label3.Text = "Part name:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(187, 161);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(306, 32);
			this.label4.TabIndex = 16;
			this.label4.Text = "Use this when you will need to combine LilyPond \"scores\" into a \"book\" and need e" +
				"ach score identified";
			// 
			// grpGrace
			// 
			this.grpGrace.Controls.Add(this.radGrace);
			this.grpGrace.Controls.Add(this.radAcc);
			this.grpGrace.Location = new System.Drawing.Point(81, 198);
			this.grpGrace.Name = "grpGrace";
			this.grpGrace.Size = new System.Drawing.Size(100, 67);
			this.grpGrace.TabIndex = 18;
			this.grpGrace.TabStop = false;
			this.grpGrace.Text = "Grace note:";
			// 
			// radGrace
			// 
			this.radGrace.AutoSize = true;
			this.radGrace.Location = new System.Drawing.Point(6, 43);
			this.radGrace.Name = "radGrace";
			this.radGrace.Size = new System.Drawing.Size(84, 17);
			this.radGrace.TabIndex = 1;
			this.radGrace.TabStop = true;
			this.radGrace.Text = "simple grace";
			this.radGrace.UseVisualStyleBackColor = true;
			// 
			// radAcc
			// 
			this.radAcc.AutoSize = true;
			this.radAcc.Checked = true;
			this.radAcc.Location = new System.Drawing.Point(6, 20);
			this.radAcc.Name = "radAcc";
			this.radAcc.Size = new System.Drawing.Size(87, 17);
			this.radAcc.TabIndex = 0;
			this.radAcc.TabStop = true;
			this.radAcc.Text = "acciaccatura";
			this.radAcc.UseVisualStyleBackColor = true;
			this.radAcc.CheckedChanged += new System.EventHandler(this.radAcc_CheckedChanged);
			// 
			// chkForcePage
			// 
			this.chkForcePage.AutoSize = true;
			this.chkForcePage.Location = new System.Drawing.Point(81, 271);
			this.chkForcePage.Name = "chkForcePage";
			this.chkForcePage.Size = new System.Drawing.Size(153, 17);
			this.chkForcePage.TabIndex = 19;
			this.chkForcePage.Text = "Use manual page breaking";
			this.chkForcePage.UseVisualStyleBackColor = true;
			this.chkForcePage.CheckedChanged += new System.EventHandler(this.chkForcePage_CheckedChanged);
			// 
			// chkSmall
			// 
			this.chkSmall.AutoSize = true;
			this.chkSmall.Location = new System.Drawing.Point(81, 294);
			this.chkSmall.Name = "chkSmall";
			this.chkSmall.Size = new System.Drawing.Size(160, 17);
			this.chkSmall.TabIndex = 20;
			this.chkSmall.Text = "Use small fonts for solo parts";
			this.chkSmall.UseVisualStyleBackColor = true;
			this.chkSmall.CheckedChanged += new System.EventHandler(this.chkSmall_CheckedChanged);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(521, 332);
			this.Controls.Add(this.chkSmall);
			this.Controls.Add(this.chkForcePage);
			this.Controls.Add(this.grpGrace);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtName);
			this.Controls.Add(this.chkVoice);
			this.Controls.Add(this.chkFirstStave);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.udFontSize);
			this.Controls.Add(this.chkRemove);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtResult);
			this.Controls.Add(this.btnGo);
			this.Controls.Add(this.btnBrowse);
			this.Controls.Add(this.txtFile);
			this.Controls.Add(this.lblFile);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.Text = "Noteworthy Text to LilyPond Converter";
			this.Load += new System.EventHandler(this.MainForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.udFontSize)).EndInit();
			this.grpGrace.ResumeLayout(false);
			this.grpGrace.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnBrowse;
		private System.Windows.Forms.TextBox txtFile;
		private System.Windows.Forms.Label lblFile;
		private System.Windows.Forms.Button btnGo;
		private System.Windows.Forms.TextBox txtResult;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckBox chkRemove;
		private System.Windows.Forms.NumericUpDown udFontSize;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.CheckBox chkFirstStave;
		private System.Windows.Forms.CheckBox chkVoice;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.GroupBox grpGrace;
		private System.Windows.Forms.RadioButton radGrace;
		private System.Windows.Forms.RadioButton radAcc;
		private System.Windows.Forms.CheckBox chkForcePage;
		private System.Windows.Forms.CheckBox chkSmall;
	}
}

